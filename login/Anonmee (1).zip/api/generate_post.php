<?php
require_once "conn.php";
$conn = new conn();
$id = $_GET['id'];




function getContentFromID($conn, $id){
    $id = htmlspecialchars($id, ENT_QUOTES);
    $response = $conn->query("SELECT * FROM posts WHERE post_id='$id' LIMIT 1");
    while($row = mysqli_fetch_array($response)){
        return $row['post_text'];
    }
    return "Sample post";
}
function getTitleFromID($conn, $id){
    $response = $conn->query("SELECT * FROM posts WHERE post_id='$id' LIMIT 1");
    while($row = mysqli_fetch_array($response)){
        return $row['post_title'];
    }
    return "Sample User";
}
?>
<div class="card" style="width:40%; margin-left: 34%;">
    <div class="card-head" style="width:89%">
        <img class = "profile" align = "left" src="img/img_avatar.png" alt="Avatar">
        <h3 class="card-title" align = "left" style="font-size:2vw;"><?php echo getTitleFromID($conn, $id);?></h3>
    </div>

    <img class="card-img-top" src="img/img_avatar1.png" alt="Card image" style="width:88%">
    <div id="appDive" style="height:100%;">
        <ul class="nav justify-content-center" id="side-nav">
            <li class="side-bitch">
                <img href="#" class="nav-link" src="img/heart icon transparent.png" alt="anon" width=100%/>
            </li>
            <li class="side-bitch">
                <img href="#" class="nav-link" src="img/comment icon transparent.png" alt="anon" width=100%/>
            </li>
            <li class="side-bitch">
                <img href="#" class="nav-link" src="img/share icon transparent.png" alt="anon" width=100%/>
            </li>
            <li class="side-bitch">
                <img href="#" class="nav-link" src="img/save icon transparent.png" alt="anon" width=100%/>
            </li>
            <li class="side-bitch" >
                <img href="#" class="nav-link" src="img/report icon transparent.png" alt="anon" width=100%/>
            </li>
        </ul>
    </div>
    <div class="card-body" style="width:89%; padding-bottom: 15%;">
        <p class="text" style="font-size:1.5vw;"><?php echo getContentFromID($conn, $id);?></p>
    </div>

</div>