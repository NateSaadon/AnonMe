<?php
require_once 'conn.php';
global $logged_in;
$action = $_GET['action'];
session_start();
//when the user attempts to create an account
//sets username and password == their inputs
//immediately hash the password
//checks if a valid username is entered
//if the username is valid the account is created
//if($action == "create_table"){
//    create_table();
//    echo "1";
//}

 if($action == "create_account"){
    $username = cleanText($_POST['username']);
    $password = cleanText($_POST['password']);
    $hash = password_hash($password, PASSWORD_DEFAULT);

    $valid_username =! is_username_taken($username);
    if($valid_username == true){
        if(strlen(validate_input($username, $password)) == 0){
            create_account($username, $hash);
            echo "1";
        }
        else{
            echo validate_input($username, $password);
        }
    }
    else{
        echo "Username Taken";
        //echo "Username taken.";
    }
}

//when the user attempts to log in
//set username and password variables == users inputs and immediately hash password
//sets the output of log_in to user_validated (TRUE/FALSE)
// if the user is validated, user is logged in, if not, invalid credentials
else if($action == "log_in"){
    $username = cleanText($_POST['username']);
    $password = cleanText($_POST['password']);
    $_SESSION['username'] = $username;
    $user_validated = log_in($username, $password);

    if($user_validated == true){
        $output = '1';
        $logged_in = true;
    }
    else{
        echo "Invalid username or password!";
    }

    echo $output;
}
else if($action == "retrieve_post_ids"){
    $conn = new conn();
    $sql = "SELECT * FROM posts ORDER BY post_id DESC LIMIT 50";
    $resp = $conn->query("$sql");
    $output = "";
    while($row = mysqli_fetch_array($resp)){
        $output .= $row['post_id'] . ",";
    }
    echo $output;
}
else if($action == "submit_post"){

//    TODO Make post_title equal to currently logged in user

    if(!isset($_SESSION['username'])) return;
    $post_title = $_SESSION['username'];
    $post_text = cleanTextPost($_POST['post_text']);
    submit_post($post_title, $post_text);
    display_posts();
}

// prevents from sql injection
function cleanText($creds){
    $creds = trim($creds); stripslashes($creds); htmlspecialchars($creds, ENT_QUOTES);
    return $creds;
}
function cleanTextPost($text){
    $cleaned_post = filter_var($text, FILTER_SANITIZE_STRING);
    return $cleaned_post;
}
//SQL Query that requests any usernames = that of which the user entered
//returns TRUE/FALSE
function is_username_taken($username){
    $conn = new conn();
    $query = $conn->query("SELECT username FROM users WHERE username = '$username'");
    while($row = mysqli_fetch_array($query)){
        return true;
    }
    return false;
}

function validate_input($username, $password){
    $result = "";
    if(strlen($username) == 0){
        $result .= "Username is required.\n";
    }
    if(strlen($password) == 0){
        $result .= "Password is required.\n";
    }
    if(strlen($username) > 16 || strlen($password) > 16 ){
        $result .= "Username or password too long\n";
    }
    return $result;
}
//SQL Query that takes in the entered username and the original hash
function create_account($username, $hash){
    $conn = new conn();
    $conn->query("INSERT INTO users VALUE (null, '$username','$hash', null, null, '', null)");
}

//SQL Query requests the password where the username is equal to that of the entered account
//Checks if the entered password == the query's returned hash using the password verify function
function log_in($username, $password){
    $conn = new conn();
    $query = $conn->query("SELECT password FROM users WHERE username = '$username'");
    $row = $query->fetchArray(MYSQLI_ASSOC);
    if (password_verify($password, $row['password'])){
        return true;
    }
    else{
        return false;
    }
}
function submit_post($post_title, $post_text){
    $conn = new conn();
    $conn->query("INSERT INTO posts VALUE(null, null, '$post_title', '$post_text', null)");
}
function display_posts(){
    $conn = new conn();
    $conn->query("SELECT * FROM posts");
}
//function create_table(){
//    $conn = new conn();
//    $conn->query("CREATE TABLE IF NOT EXISTS users(
//            user_id INT(6) AUTO_INCREMENT PRIMARY KEY,
//            username VARCHAR(20) NOT NULL,
//            password VARCHAR(60) NOT NULL,
//            bio VARCHAR(250),
//            pic VARCHAR(30),
//            date_joined TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
//            DOB VARCHAR(8))");
//}
